<html>
<head>
<title>Exito</title>
</head>
<center>
<body>
<?=heading('El archivo se ha subido correctamente', 4);?>

<h5><?=anchor('admin', 'Regresar'); ?></h5>
<h5><?=anchor('admin/info', 'Listado de archivos para descargar'); ?></h5>

</body></center>
</html>